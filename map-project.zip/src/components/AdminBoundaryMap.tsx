/* eslint-disable @typescript-eslint/no-explicit-any */
import { Box, Button, Heading, Spinner } from "@chakra-ui/react";
import type { LatLngBoundsExpression, Layer } from "leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { useEffect, useRef, useState } from "react";
import { IoIosArrowBack } from "react-icons/io";
import { GeoJSON, MapContainer, TileLayer, useMap } from "react-leaflet";
import { useGetMapDataQuery } from "../../services/apiSlice";

const FitBoundsHandler = ({ geoJsonData }: { geoJsonData: any }) => {
  const map = useMap();

  useEffect(() => {
    if (geoJsonData) {
      const layer = L.geoJSON(geoJsonData);
      const bounds: LatLngBoundsExpression = layer.getBounds();
      if (bounds.isValid()) {
        map.fitBounds(bounds, { padding: [20, 20] }); // padding দিলে একটু margin থাকবে
      }
    }
  }, [geoJsonData, map]);

  return null;
};

interface Properties {
  division_name?: string;
  district_name?: string;
  upazila_name?: string;
  union_name?: string;
  mauza_name?: string;
}

const getName = (properties: Properties, mapTitle: string): string => {
  let name = "Unknown";
  if (mapTitle === "divisions") {
    name = properties?.division_name || "Unknown";
  } else if (mapTitle === "districts") {
    name = properties?.district_name || "Unknown";
  } else if (mapTitle === "upazilas") {
    name = properties?.upazila_name || "Unknown";
  } else if (mapTitle === "unions") {
    name = properties?.union_name || "Unknown";
  } else if (mapTitle === "mouzas") {
    name = properties?.mauza_name || "Unknown";
  } else {
    name = properties?.mauza_name || "Unknown";
  }
  return name;
};

const AdminBoundaryMap = () => {
  const [mapState, setMapState] = useState<{
    map: "divisions" | "districts" | "upazilas" | "unions" | "mouzas";
    code: number[];
  }>({
    map: "divisions",
    code: [],
  });

  const [titles, setTitles] = useState<Array<string>>(["Bangladesh"]);

  const { data, isLoading, isFetching, isSuccess } = useGetMapDataQuery(
    `${mapState.map}/${mapState.code.join("/")}`
  );

  const geoJsonRef = useRef<any>(null);

  const color = {
    divisions: "#6666ff",
    districts: "#009999",
    upazilas: "#3056C9",
    unions: "#993366",
    mouzas: "#ff6666",
  };

  const normalStyle = {
    color: "#fff",
    weight: 1.3,
    fillColor: color[mapState.map],
    fillOpacity: 0.7,
  };

  const highlightFeature = (e: any) => {
    const layer = e.target;
    layer.setStyle({
      fillColor: "#ff9966",
      weight: 1,
      color: "#000",
      fillOpacity: 0.6,
    });
    layer.bringToFront();
  };

  const resetHighlight = (e: any) => {
    geoJsonRef.current?.resetStyle(e.target);
  };

  const onEachFeature = (feature: any, layer: Layer) => {
    layer.on({
      mouseover: highlightFeature,
      mouseout: resetHighlight,
      click: () => {
        const {
          division_code: divisionCode,
          district_code: districtCode,
          upazila_code: upazilaCode,
          union_code: unionCode,
        } = feature.properties || {};

        const name = getName(feature.properties, mapState.map);

        if (divisionCode && !districtCode && !upazilaCode) {
          setMapState({ map: "districts", code: [divisionCode] });
          setTitles((prev) => [...prev, name]);
        } else if (districtCode && !upazilaCode) {
          setMapState({ map: "upazilas", code: [divisionCode, districtCode] });
          setTitles((prev) => [...prev, name]);
        } else if (upazilaCode && !unionCode) {
          setMapState({
            map: "unions",
            code: [divisionCode, districtCode, upazilaCode],
          });
          setTitles((prev) => [...prev, name]);
        } else if (unionCode) {
          setMapState({
            map: "mouzas",
            code: [divisionCode, districtCode, upazilaCode, unionCode],
          });
          if (titles.length < 5) {
            setTitles((prev) => [...prev, name]);
          }
        }
      },
    });

    const name = getName(feature.properties, mapState.map);

    layer.bindTooltip(name, {
      sticky: true,
      direction: "top",
      className: "district-tooltip",
    });
  };

  console.log(titles);

  const zoom = {
    divisions: 7,
    districts: 8,
    upazilas: 10,
    unions: 9,
    mouzas: 11,
    villages: 12,
  };

  const handleBack = () => {
    if (mapState.map === "divisions") {
      return;
    } else if (mapState.map === "districts") {
      setMapState({ map: "divisions", code: [] });
    } else if (mapState.map === "upazilas") {
      setMapState({
        map: "districts",
        code: [mapState.code[0]],
      });
    } else if (mapState.map === "unions") {
      setMapState({
        map: "upazilas",
        code: [mapState.code[0], mapState.code[1]],
      });
    } else if (mapState.map === "mouzas") {
      setMapState({
        map: "unions",
        code: [mapState.code[0], mapState.code[1], mapState.code[2]],
      });
    }

    setTitles((prev) => {
      const newTitles = [...prev];

      newTitles.pop();

      return newTitles;
    });
  };

  console.log(data);

  const currentTitle = titles[titles.length - 1];

  const getTitleType = (mapType: string) => {
    switch (mapType) {
      case "divisions":
        return "";
      case "districts":
        return "Division";
      case "upazilas":
        return "District";
      case "unions":
        return "Upazila";
      case "mouzas":
        return "Union";
    }
    return "";
  };

  return (
    <Box>
      <MapContainer
        key={`${mapState.code.join("-")}`}
        center={[23.685, 90.3563]}
        zoom={zoom[mapState.map]}
        style={{ height: "100vh", width: "100%", padding: "5px" }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          // attribution="&copy; OpenStreetMap contributors"
        />
        {data && !isLoading && !isFetching && isSuccess && (
          <>
            <GeoJSON
              key={`${mapState.map}-${mapState.code.join("-")}-${
                data?.features?.length || 0
              }`}
              data={data}
              style={() => normalStyle}
              onEachFeature={onEachFeature}
              ref={(ref) => {
                geoJsonRef.current = ref;
              }}
            />
            <FitBoundsHandler geoJsonData={data} />
          </>
        )}
      </MapContainer>
      {(isFetching || isLoading) && (
        <Box
          position="fixed"
          top={0}
          left={0}
          width="100vw"
          height="100vh"
          bg="rgba(0, 0, 0, 0.5)"
          display="flex"
          alignItems="center"
          justifyContent="center"
          zIndex={9999}
        >
          <Spinner
            size="xl"
            color="blue.600"
            css={{ "--spinner-track-color": "colors.gray.200" }}
            borderWidth="5px"
          />
        </Box>
      )}

      <Box
        position="fixed"
        top={5}
        left={0}
        width="100vw"
        display="flex"
        flexDir={"column"}
        justifyContent="center"
        alignItems={"center"}
        zIndex={9999}
      >
        <Heading
          px={5}
          py={2}
          bg={"white"}
          borderRadius="md"
          border={"1px solid #006400"}
          mb={3}
        >
          {currentTitle}
          {getTitleType(mapState.map) ? (
            <Box as={"span"} fontSize={"sm"} ml={1} color={"gray.700"}>
              ({getTitleType(mapState.map)})
            </Box>
          ) : (
            ""
          )}
        </Heading>
        {isSuccess && mapState.map !== "divisions" && (
          <Button
            onClick={handleBack}
            disabled={isFetching || isLoading}
            colorPalette={"blue"}
          >
            <Box fontSize="10px">
              <IoIosArrowBack />
            </Box>
            Back
          </Button>
        )}
      </Box>
    </Box>
  );
};

export default AdminBoundaryMap;
