import { Box } from "@chakra-ui/react";
import "leaflet/dist/leaflet.css";
import "./App.css";
import AdminBoundaryMap from "./components/AdminBoundaryMap";
import { getUserHash } from "./lib/encryptPassword";

function App() {
  // const onRegionClick = () => {};

  const userId = 197;
  const password = "Amirul2347";

  const userHash = getUserHash(userId, password);
  console.log("User Hash:", userHash);

  console.log(userHash);
  return (
    <Box>
      <AdminBoundaryMap />
      {/* <FileUploadWithProgress />
      <Video /> */}
    </Box>
  );
}

export default App;
