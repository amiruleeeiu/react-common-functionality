// services/apiSlice.ts
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const apiSlice = createApi({
  reducerPath: "api", // optional name for the slice
  baseQuery: fetchBaseQuery({
    baseUrl: "http://localhost:3000/api",
  }),
  keepUnusedDataFor: 100,
  endpoints: (builder) => ({
    getDivisions: builder.query({
      query: () => "/divisions", // GET /posts
    }),
    getMapData: builder.query({
      query: (urlStr) => `/${urlStr}`, // GET /posts
    }),
    getPostById: builder.query({
      query: (id) => `posts/${id}`, // GET /posts/:id
    }),
    createPost: builder.mutation({
      query: (newPost) => ({
        url: "posts",
        method: "POST",
        body: newPost,
      }),
    }),
  }),
});

// Export hooks for usage in functional components
export const {
  useGetDivisionsQuery,
  useGetPostByIdQuery,
  useCreatePostMutation,
  useGetMapDataQuery,
} = apiSlice;
